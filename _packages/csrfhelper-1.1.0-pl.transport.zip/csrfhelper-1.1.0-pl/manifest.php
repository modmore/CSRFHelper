<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Copyright 2018, Mark Hamstra <hello@markhamstra.com>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
',
    'readme' => 'CSRF Helper
-----------

CSRF Helper is a tool for MODX to secure forms against cross-site request forgery (CSRF) vulnerabilities.

The Open Web Application Security Project (OWASP) explains CSRF as follows:

    Cross-Site Request Forgery (CSRF) is an attack that forces an end user to
    execute unwanted actions on a web application in which they\'re currently authenticated.
    CSRF attacks specifically target state-changing requests, not theft of data, since the
    attacker has no way to see the response to the forged request.

    With a little help of social engineering (such as sending a link via email or chat),
    an attacker may trick the users of a web application into executing actions of the
    attacker\'s choosing.

    If the victim is a normal user, a successful CSRF attack can force the user to perform
    state changing requests like transferring funds, changing their email address, and so forth.
    If the victim is an administrative account, CSRF can compromise the entire web application.

    https://www.owasp.org/index.php/Cross-Site_Request_Forgery_(CSRF)

Documentation detailing the different uses and supported tools in CSRF Helper can be found at:

    https://docs.modmore.com/en/Open_Source/CSRFHelper/index.html
',
    'changelog' => 'CSRF Helper 1.1.0-pl
----------------------
Released on 2022-04-14

- Fix MODX3 compatibility
- Allow translating the error message through a new lexicon [#3]
- Update paragonie/random_compat to 2.0.21

CSRF Helper 1.0.0-pl
----------------------
Released on 2019-07-26

- Make sure tokens that expired are considered invalid
- Allow logging out without a CSRF token [#2]

CSRF Helper 1.0.0-rc1
----------------------
Released on 2018-10-23

- Initial release.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1a4c9396cb7778def435cee59769d12c',
      'native_key' => 'csrfhelper',
      'filename' => 'modNamespace/8241ed69e2a83ed131729b49c93fffad.vehicle',
      'namespace' => 'csrfhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a785edfd97bcc94ddec77a1c05213a7a',
      'native_key' => NULL,
      'filename' => 'modCategory/4ffd7e8d66034de184da5e8e79b2ca9b.vehicle',
      'namespace' => 'csrfhelper',
    ),
  ),
);