<?php
namespace modmore\CSRFHelper;


class InvalidTokenException extends \Exception
{

}