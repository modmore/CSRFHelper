<?php

$_lang['csrfhelper.error'] = 'Your security token did not match the expected token.';