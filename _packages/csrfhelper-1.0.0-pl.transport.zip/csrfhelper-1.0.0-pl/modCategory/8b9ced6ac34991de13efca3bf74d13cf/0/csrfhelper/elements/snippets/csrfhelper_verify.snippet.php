<?php
/**
 * CSRF Helper
 *
 * This snippet validates a CSRF token as a standalone snippet, for custom form handlers.
 *
 * @var modX $modx
 * @var array $scriptProperties
 *
 */

$path = $modx->getOption('csrfhelper.core_path', null, MODX_CORE_PATH . 'components/csrfhelper/');
$path .= 'vendor/autoload.php';
require_once $path;

use modmore\CSRFHelper\Csrf;
use modmore\CSRFHelper\InvalidTokenException;
use modmore\CSRFHelper\Storage\SessionStorage;

$key = $modx->getOption('key', $scriptProperties, 'default');
$submitVar = $modx->getOption('submitVar', $scriptProperties, '');
$validSnippet = $modx->getOption('ifValidSnippet', $scriptProperties, '');
$validMessage = $modx->getOption('ifValidMessage', $scriptProperties, '');
$invalidSnippet = $modx->getOption('ifInvalidSnippet', $scriptProperties, '');
$invalidMessage = $modx->getOption('ifInvalidMessage', $scriptProperties, '');
$notPostSnippet = $modx->getOption('ifNoPostSnippet', $scriptProperties, '');
$notPostMessage = $modx->getOption('ifNoPostMessage', $scriptProperties, '');

// Don't do anything if the request isn't a POST or the submitVar isn't present
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && ($submitVar !== '' || !empty($_POST[$submitVar]))) {
    if ($notPostSnippet !== '') {
        return $modx->runSnippet($notPostSnippet, $scriptProperties);
    }
    return $notPostMessage;
}


$storage = new SessionStorage();
$csrf = new Csrf($storage, $modx->getUser());

// Grab the token - even if it's empty, then we treat that as the token (which will fail, rightly so)
$token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';

try {
    $csrf->check($key, $token);

    if ($validSnippet !== '') {
        return $modx->runSnippet($validSnippet, $scriptProperties);
    }
    return $validMessage;
}
catch (InvalidTokenException $e) {
    if ($invalidSnippet !== '') {
        return $modx->runSnippet($invalidSnippet, $scriptProperties);
    }
    return $invalidMessage;
}
catch (Error $e) {
    throw $e;
}
catch (Exception $e) {
    $modx->log(modX::LOG_LEVEL_ERROR, '[csrfhelper_verify] Could not safely generate the CSRF token: ' . $e->getMessage());
    if ($invalidSnippet !== '') {
        return $modx->runSnippet($invalidSnippet, $scriptProperties);
    }
    return $invalidMessage;
}
